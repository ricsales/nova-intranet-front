import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './modules/main/main.component';
import { DefaultComponent } from './layouts/default/default.component';
import { NoticiasComponent } from './modules/noticias/noticias.component';
import { ServicosComponent } from './modules/servicos/servicos.component';
import { DocumentosComponent } from './modules/documentos/documentos.component';


const routes: Routes = [{
  path: '',
  component: DefaultComponent,
  children: [{
    path: '',
    component: MainComponent
  },
  {
    path: 'noticias',
    component: NoticiasComponent
  },
  {
    path: 'noticias/:idNoticia',
    component: NoticiasComponent
  },
  {
    path: 'servicos',
    component: ServicosComponent
  },
  {
    path: 'documentos',
    component: DocumentosComponent
  }
  ]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

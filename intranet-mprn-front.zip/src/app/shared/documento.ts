export class Documento {
    nome:string;
    caminhoArquivo:string;
    tipoArquivo:string;
    tamanhoArquivo:number;
    dataUltimAModificadao: Date;
    resumoArquivo: string;
}


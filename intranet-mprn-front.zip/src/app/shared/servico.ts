export class Servico {
    nome: string;
    descricao: string;
    link: string;
    icone: string;
    tipo: string;
}

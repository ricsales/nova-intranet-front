export class Servidor {
    nome: string;
    cargo: string;
    imagem: string;
    matricula: string;
    lotacao: string;
    dataDeAdmissao: Date;
    horariosDeTrabalho: Date[];
    designacoesEmVigor: any[];
    bancoDeHorasPositivas: any;
    bancoDeHorasNegativas: any;
    feriasEAfastamentos: any[];
}

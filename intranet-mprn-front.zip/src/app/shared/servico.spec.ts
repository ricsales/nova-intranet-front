import { Servico } from './servico';

describe('Servico', () => {
  it('should create an instance', () => {
    expect(new Servico()).toBeTruthy();
  });
});

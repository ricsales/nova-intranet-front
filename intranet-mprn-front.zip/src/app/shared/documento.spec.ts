import { Documento } from './documento';

describe('Documento', () => {
  it('should create an instance', () => {
    expect(new Documento()).toBeTruthy();
  });
});

export class Noticia {
    titulo: string;
    subtitulo: string;
    imagem: string;
    codigoVideoYoutube: string;
    conteudo: string;
}
